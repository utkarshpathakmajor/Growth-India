
console.log("Growth India website is live!");
